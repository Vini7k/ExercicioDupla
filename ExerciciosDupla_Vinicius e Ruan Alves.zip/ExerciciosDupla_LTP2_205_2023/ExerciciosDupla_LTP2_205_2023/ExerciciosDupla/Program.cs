﻿using Microsoft.VisualBasic.FileIO;
using System;

class Program
{
    static void Main()
    {
        int option;
        do{
            Console.WriteLine("\n==MENU==\n");
            Console.WriteLine("Escolha uma opção:");
            Console.WriteLine("0 - Sair");
            Console.WriteLine("1 - Somar 2 numeros: ");
            Console.WriteLine("2 - Transformar metros em milimetros: ");
            Console.WriteLine("3 - Calcula aumento:");
            Console.WriteLine("4 - Calcula desconto:");
            Console.WriteLine("5 - Aluguel de carro: ");
            Console.WriteLine("6 - Calcular IMC: ");
            Console.WriteLine("7 - Tabuada de cada número: ");
            Console.WriteLine("8 - Múltiplos de 3 entre 0 e 10: ");
            Console.WriteLine("9 - Fatoriais de 1 até 10: ");
            Console.WriteLine("10 - Imposto de renda: ");
            Console.WriteLine("11 - Advinhar número: ");
            Console.WriteLine("12 - Financiamento de veículo: ");
            Console.WriteLine("13 - Aposentadoria: ");
            Console.WriteLine("Escolha um calculo para ser realizado: ");


            string input = Console.ReadLine();
            option = int.Parse(input);

            switch (option)
            {
                case 0:
                    return;
                case 1:
                    FuncaoSoma();
                    break;
                case 2:
                    FuncaoMetroMilimetro();
                    break;
                case 3:
                    FuncaoAumento();
                    break;
                case 4:
                    FuncaoDesconto(); 
                    break;
                case 5:
                    FuncaoAluguel();
                    break;
                case 6:
                    FuncaoImc();
                    break;
                case 7:
                    FuncaoTabuada();
                    break;
                case 8:
                    FuncaoMultiplo();
                    break;
                case 9:
                    FuncaoFatorial();
                    break;
                case 10:
                    FuncaoImposto();
                    break;
                case 11:
                    FuncaoAdivinha();
                    break;
                case 12:
                    FuncaoFinanciamento();
                    break;
                case 13:
                    FuncaoAposentadoria();
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;

            } 
        } while (option != 0);

        void FuncaoSoma()
        {
            int soma, numSoma, numSoma2;
            
            Console.WriteLine("Digite um numero: ");
            numSoma = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite outro numero: ");
            numSoma2 = int.Parse(Console.ReadLine());

            soma = numSoma + numSoma2;
            Console.WriteLine($"{numSoma} + {numSoma2} = {soma}");

        }
        void FuncaoMetroMilimetro()
        {
            Console.WriteLine("Informe o valor em metros: ");
            float metro = float.Parse(Console.ReadLine());
            Console.WriteLine($"Valor em metros = {metro}");
            double milimetros = metro * 1000;
            Console.WriteLine($"Valor em milímetros = {milimetros}");
        }
        void FuncaoAumento()
        {
            Console.WriteLine("Informe seu salario: ");
            double salario = double.Parse(Console.ReadLine());
            Console.WriteLine("Informe o percentual de aumento: ");
            double porcentagemAumento = double.Parse(Console.ReadLine()) / 100;
            double aumento = salario * porcentagemAumento;
            Console.WriteLine($"Seu aumento = R${aumento}");
            double novoSalario = salario + aumento;
            Console.WriteLine($"Seu novo salario = R${novoSalario}");
            
        }
        void FuncaoDesconto()
        {
            Console.WriteLine("Informe o valor: ");
            float real = float.Parse(Console.ReadLine());
            Console.WriteLine("Informe a porcentagem do desconto: ");
            float desconto = float.Parse(Console.ReadLine());
            float valorcomdesconto = real - (real * desconto) / 100;
            Console.WriteLine($"Valor com desconto = R${valorcomdesconto}");
            Console.WriteLine($"Valor sem desconto = R${real}");
         
        }
        void FuncaoAluguel()
        {
            Console.WriteLine("Informe o tempo de uso em dias: ");
            byte numerosDias = byte.Parse(Console.ReadLine());
            Console.WriteLine("Informe a quilometragem inicial:");
            double quilometroInicial = double.Parse(Console.ReadLine());
            Console.WriteLine("Informe a quilometragem final:");
            double quilometroFinal = double.Parse(Console.ReadLine());

            int valorDia = (int)(numerosDias * 95);
            double valorQuilometro = (double)(quilometroFinal - quilometroInicial) * 0.35;
            double valorTotal = (double)(valorQuilometro + valorDia);
            Console.WriteLine($"Valor a ser pago{valorTotal}");
        }
        void FuncaoImc()
        {
            Console.WriteLine("Informe sua altura em metros(x,xx): ");
            float altura = float.Parse(Console.ReadLine());
            Console.WriteLine("Informe seu peso em kg : ");
            float peso = float.Parse(Console.ReadLine());
            float imc = peso / (altura * altura);
            Console.WriteLine($"Seu índice de massa corporal é igual:{imc}");
            if (imc < 18.5)
            {
                Console.WriteLine("Voce está baixo do peso");
            }
            else if (imc <= 24.9)
            {
                Console.WriteLine("Você possui o peso ideal");
            }
            else if (imc <= 29.9)
            {
                Console.WriteLine("Você está levemente acima do peso");
            }
            else if (imc <= 34.9)
            {
                Console.WriteLine("Você possui obesidade grau 1");
            }
            else if (imc <= 39.9)
            {
                Console.WriteLine("Você possui obesidade grau 2");
            }
            else if (imc >= 40)
            {
                Console.WriteLine("Você possui obesidade mórbida");
            }
        }
        void FuncaoTabuada()
        {
            int form, cont, num;

            Console.Write("Digite o numero para a tabuada desejada: ");
            num = int.Parse(Console.ReadLine());

            for (cont = 1; cont <= 10; ++cont)
            {
                form = num * cont;
                Console.WriteLine($"{num} x {cont} = {form}");

            }
        }
        void FuncaoMultiplo()
        {
            float[] multiplos = new float[101];
            multiplos[0] = 3;
            for (int i = 1; i < multiplos.Length; i++)
            {
                multiplos[i] = i + 1;
                if (i % 3 == 0)
                {
                    Console.WriteLine($"É  multiplo de 3 {i}");
                }

            }
            Console.WriteLine("Esses são os multiplos de 3 até 10= ");
        }
        void FuncaoFatorial()
        {
            float[] fatorial = new float[11];
            fatorial[0] = 1;

            for (int i = 1; i < fatorial.Length; i++)
            {
                fatorial[i] = fatorial[i - 1] * i;
                Console.WriteLine($"O fatorial de: {i} é: {fatorial[i]}");
            }
        }
        void FuncaoImposto()
        {
            Console.WriteLine("Informe seu salario");
            double salarioBruto = double.Parse(Console.ReadLine());
            if (salarioBruto < 1903.98)
            {
                Console.WriteLine("Não recebe desconto");
            }
            else 
                if (salarioBruto <= 2826.65)
            {
                double porcentagemDesconto = 7.5 / 100;
                double salarioDesconto = salarioBruto - (salarioBruto * porcentagemDesconto);
                Console.WriteLine($"Salario com desconto igual a {salarioDesconto}");
                double valorapagar = salarioBruto * porcentagemDesconto;
                Console.WriteLine($"Valor a pagar = {valorapagar}");
            }
                 else 
                    if (salarioBruto <= 3751.05)
                 {
                     double porcentagemDesconto = 15.0 / 100;
                     double salarioDesconto = salarioBruto - (salarioBruto * porcentagemDesconto);
                     Console.WriteLine($"Salario com desconto igual a {salarioDesconto}");
                     double valorapagar = salarioBruto * porcentagemDesconto;
                     Console.WriteLine($"Valor a pagar = {valorapagar}");

                 }       
                        else 
                            if (salarioBruto <= 4664.68)
                        {
                            double porcentagemDesconto = 22.5 / 100;
                            double salarioDesconto = salarioBruto - (salarioBruto * porcentagemDesconto);
                            Console.WriteLine($"Salario com desconto igual a {salarioDesconto}");
                            double valorapagar = salarioBruto * porcentagemDesconto;
                            Console.WriteLine($"Valor a pagar = {valorapagar}");
                        }
                            else 
                                if (salarioBruto > 4664.68)
                             {
                                double porcentagemDesconto = 27.5 / 100;
                                double salarioDesconto = salarioBruto - (salarioBruto * porcentagemDesconto);
                                Console.WriteLine($"Salario com desconto igual a {salarioDesconto}" );
                                double valorapagar = salarioBruto * porcentagemDesconto;
                                Console.WriteLine($"Valor a pagar = {valorapagar}");
            }
        }
        void FuncaoAdivinha()
        {
            int tentativas = 0;
            int num = 0;
            Random r = new Random();
            int a = r.Next(0, 100);
            while (true)
            {
                tentativas++;

                Console.WriteLine("Advinhe o numero!");
                try
                {
                    num = int.Parse(Console.ReadLine());
                }
                catch 
                {
                    Console.WriteLine("Um número, nao uma letra."); 
                }
                if (num < a) 
                {
                    Console.WriteLine($"Ele é maior que {num}");
                }
                else 
                    if (num > a)
                     { 
                       Console.WriteLine($"Ele é menor que {num}"); 
                      }
                if (tentativas >= 10)
                {
                    Console.WriteLine($"Erroou, o número era {a}");
                    
                    break;
                }
                if (num == a)
                {
                    Console.WriteLine($"Acertou depois de {tentativas} tentativas.");

                    break;

                }

            }

        }
        void FuncaoFinanciamento()
        {
            Console.WriteLine("Informe o valor do veiculo:");
            double valorVeiculo = double.Parse(Console.ReadLine());
            Console.WriteLine("Informe o numero de parcelas:");
            double numeroParcelas = double.Parse(Console.ReadLine());
            double taxaMensal = 0.0193;
            double taxaAdm = 0.0001;
            double juros = valorVeiculo * taxaMensal * numeroParcelas;
            double jurosAdm = taxaAdm * valorVeiculo;
            double juroSimples = valorVeiculo + juros;
            for (int i = 0; i <= numeroParcelas; i++)
            {
                juros *= 1 + taxaMensal;
                jurosAdm *= 1+ taxaAdm;
            }

            double montante = valorVeiculo + juros + jurosAdm;
            double valorSemAdm = montante - jurosAdm;
            double valorSemJuros = montante - juros;
            Console.WriteLine($"Montante sem juros = {valorSemJuros}");
            Console.WriteLine($"Montante sem juros administrativo= {valorSemAdm}");
            Console.WriteLine($"Valor total do veículo = {montante}");
        }
        void FuncaoAposentadoria()
        {
            double jurosComposto = 0, acumulador = 0, montante = 0;
            Console.WriteLine("Informe a sua idade: ");
            double idade = int.Parse(Console.ReadLine());
            Console.WriteLine("Informe com quantos anos quer se aposentar: ");
            double idadeFinal = int.Parse(Console.ReadLine());
            Console.WriteLine("Informe o quanto quer investir por mes: ");
            double valorAposentadoria = double.Parse(Console.ReadLine());
            double taxaRendimento = 0.01;
            double anosRendimento = (idadeFinal - idade) * 12;

            for (double i = 0; i <= anosRendimento; i++)
            {
                acumulador = acumulador + valorAposentadoria;
                jurosComposto = jurosComposto + (acumulador * 0.01);
                montante = acumulador + jurosComposto;

            }

            double salarioLiquido = montante * taxaRendimento;
            Console.WriteLine($"Montante igual a {montante}");
            Console.WriteLine($"Salario liquido igual a {salarioLiquido}");
        }
    }
    
}